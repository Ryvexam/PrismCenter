import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const root = process.cwd();

function read(relativePath) {
  return readFileSync(resolve(root, relativePath), 'utf8');
}

function write(relativePath, content) {
  const target = resolve(root, relativePath);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, content.endsWith('\n') ? content : `${content}\n`, 'utf8');
}

function replaceOnce(content, search, replacement, label) {
  const firstIndex = content.indexOf(search);
  if (firstIndex < 0) throw new Error(`Missing replacement target: ${label}`);
  if (content.indexOf(search, firstIndex + search.length) >= 0) {
    throw new Error(`Replacement target is not unique: ${label}`);
  }
  return `${content.slice(0, firstIndex)}${replacement}${content.slice(firstIndex + search.length)}`;
}

function replaceRange(content, start, end, replacement, label) {
  const startIndex = content.indexOf(start);
  if (startIndex < 0) throw new Error(`Missing range start: ${label}`);
  const endIndex = content.indexOf(end, startIndex + start.length);
  if (endIndex < 0) throw new Error(`Missing range end: ${label}`);
  if (content.indexOf(start, startIndex + start.length) >= 0) {
    throw new Error(`Range start is not unique: ${label}`);
  }
  return `${content.slice(0, startIndex)}${replacement}${content.slice(endIndex + end.length)}`;
}

const scenariosSource = `const DEFAULT_POWER_MW = 300;
const DEFAULT_ELECTRICITY_PRICE_EUR_PER_KWH = 0.08;
const HOURS_PER_DAY = 24;
const DAYS_PER_MONTH = 30;
const HOURS_PER_YEAR = 8760;

export const PROFILE_PRESETS = [
  {
    id: 'colossus',
    label: 'Hyperscale IA',
    footprint: '300 MW',
    reference: 'Ordre de grandeur Colossus 1',
    description: '200 000 GPU · 140 MW GPU · charge totale site modélisée à 300 MW.',
    powerNeedMw: 300,
    gpuCount: 200000,
    gpuPowerMw: 140,
    gpuPowerAssumptionWatts: 700,
    electricityPriceEurPerKwh: 0.08,
    weights: { access: 0.03, cooling: 0.09, energy: 0.32, grid: 0.31, land: 0.14, risk: 0.11 },
  },
  {
    id: 'gigawatt',
    label: 'Campus gigawatt',
    footprint: '1 000 MW',
    reference: 'Stress test hyperscale 1 GW',
    description: 'Scénario d’expansion extrême · 1 million de GPU équivalents · réseau 400 kV indispensable.',
    powerNeedMw: 1000,
    gpuCount: 1000000,
    gpuPowerMw: 700,
    gpuPowerAssumptionWatts: 700,
    electricityPriceEurPerKwh: 0.08,
    weights: { access: 0.02, cooling: 0.08, energy: 0.34, grid: 0.34, land: 0.13, risk: 0.09 },
  },
  {
    id: 'training',
    label: 'Cluster entraînement',
    footprint: '200 MW',
    reference: 'Grand cluster d’entraînement',
    description: 'Priorité à la puissance bas carbone, au raccordement HTB et à la marge foncière.',
    powerNeedMw: 200,
    electricityPriceEurPerKwh: 0.08,
    weights: { access: 0.05, cooling: 0.1, energy: 0.31, grid: 0.22, land: 0.13, risk: 0.19 },
  },
  {
    id: 'sovereign',
    label: 'Campus souverain',
    footprint: '80 MW',
    reference: 'Campus souverain',
    description: 'Équilibre entre énergie, risques naturels et refroidissement.',
    powerNeedMw: 80,
    electricityPriceEurPerKwh: 0.08,
    weights: { access: 0.06, cooling: 0.11, energy: 0.28, grid: 0.18, land: 0.14, risk: 0.23 },
  },
  {
    id: 'inference',
    label: 'Inférence régionale',
    footprint: '30 MW',
    reference: 'Inférence régionale',
    description: 'L’accès aux équipes et aux bassins urbains devient plus important.',
    powerNeedMw: 30,
    electricityPriceEurPerKwh: 0.08,
    weights: { access: 0.24, cooling: 0.09, energy: 0.22, grid: 0.14, land: 0.11, risk: 0.2 },
  },
];

export function profileToPowerNeedMw(profile = PROFILE_PRESETS[0]) {
  const powerMw = Number(profile?.powerNeedMw);
  return Number.isFinite(powerMw) && powerMw > 0 ? powerMw : DEFAULT_POWER_MW;
}

export function buildEnergyEconomics(profile = PROFILE_PRESETS[0]) {
  const powerMw = profileToPowerNeedMw(profile);
  const electricityPriceEurPerKwh = normalizePositiveNumber(
    profile?.electricityPriceEurPerKwh,
    DEFAULT_ELECTRICITY_PRICE_EUR_PER_KWH,
  );
  const gpuCount = normalizePositiveNumber(profile?.gpuCount, 0);
  const gpuPowerAssumptionWatts = normalizePositiveNumber(profile?.gpuPowerAssumptionWatts, 0);
  const declaredGpuPowerMw = normalizePositiveNumber(profile?.gpuPowerMw, 0);
  const derivedGpuPowerMw = gpuCount > 0 && gpuPowerAssumptionWatts > 0 ? (gpuCount * gpuPowerAssumptionWatts) / 1_000_000 : 0;
  const gpuPowerMw = declaredGpuPowerMw || derivedGpuPowerMw;
  const dailyEnergyGwh = (powerMw * HOURS_PER_DAY) / 1000;
  const monthlyEnergyGwh = (powerMw * HOURS_PER_DAY * DAYS_PER_MONTH) / 1000;
  const annualEnergyTwh = (powerMw * HOURS_PER_YEAR) / 1_000_000;
  const dailyCostEur = powerMw * 1000 * HOURS_PER_DAY * electricityPriceEurPerKwh;
  const monthlyCostEur = dailyCostEur * DAYS_PER_MONTH;
  const annualCostEur = powerMw * 1000 * HOURS_PER_YEAR * electricityPriceEurPerKwh;

  return {
    annualCostEur,
    annualEnergyTwh,
    dailyCostEur,
    dailyEnergyGwh,
    electricityPriceEurPerKwh,
    gpuCount,
    gpuPowerAssumptionWatts,
    gpuPowerMw,
    gpuSharePct: gpuPowerMw > 0 ? (gpuPowerMw / powerMw) * 100 : null,
    monthlyCostEur,
    monthlyEnergyGwh,
    powerMw,
  };
}

function normalizePositiveNumber(value, fallback) {
  const numericValue = Number(value);
  return Number.isFinite(numericValue) && numericValue > 0 ? numericValue : fallback;
}
`;

const scenariosTestSource = `import assert from 'node:assert/strict';
import test from 'node:test';
import { buildEnergyEconomics, PROFILE_PRESETS, profileToPowerNeedMw } from './scenarios.js';

test('defaults to the 300 MW hyperscale profile', () => {
  assert.equal(PROFILE_PRESETS[0].id, 'colossus');
  assert.equal(profileToPowerNeedMw(PROFILE_PRESETS[0]), 300);
});

test('computes Colossus-scale continuous energy and electricity cost', () => {
  const economics = buildEnergyEconomics(PROFILE_PRESETS[0]);

  assert.equal(economics.dailyEnergyGwh, 7.2);
  assert.equal(economics.monthlyEnergyGwh, 216);
  assert.equal(economics.annualEnergyTwh, 2.628);
  assert.equal(economics.dailyCostEur, 576000);
  assert.equal(economics.monthlyCostEur, 17280000);
  assert.equal(economics.annualCostEur, 210240000);
  assert.ok(Math.abs(economics.gpuSharePct - 46.6666666667) < 1e-9);
});

test('computes the 1 GW stress-test scale', () => {
  const profile = PROFILE_PRESETS.find(({ id }) => id === 'gigawatt');
  const economics = buildEnergyEconomics(profile);

  assert.equal(economics.dailyEnergyGwh, 24);
  assert.equal(economics.annualEnergyTwh, 8.76);
  assert.equal(economics.dailyCostEur, 1920000);
  assert.equal(economics.annualCostEur, 700800000);
});

test('rejects invalid power inputs', () => {
  assert.equal(profileToPowerNeedMw({ powerNeedMw: 0 }), 300);
  assert.equal(profileToPowerNeedMw({ powerNeedMw: Number.NaN }), 300);
});
`;

const agentsSource = `# AGENTS.md

## Scope

PrismCenter is a React 19 and Vite application for exploratory AI data-center siting in France. Keep the UI in French and keep code, identifiers, branches, commits, and technical documentation in English.

## Git workflow

- Never commit directly to \`main\` or \`dev\`.
- Branch from \`dev\` using \`feat/*\`, \`fix/*\`, \`refactor/*\`, \`docs/*\`, \`test/*\`, \`chore/*\`, \`ci/*\`, \`security/*\`, or \`perf/*\`.
- Open a pull request to \`dev\`; promote \`dev\` to \`main\` through a second pull request.
- Use Conventional Commits.

## Required checks

Run these commands before opening a pull request:

\`\`\`bash
npm ci
npm test
npm run build
npm audit --audit-level=high
\`\`\`

## Architecture rules

- Keep scenario assumptions in \`src/data/scenarios.js\`; do not hard-code profile IDs in scoring functions.
- Every scenario must expose an explicit \`powerNeedMw\` value and weights that sum to 1.
- Electricity economics use continuous load, 24 hours per day, 30 days per modeled month, and 8,760 hours per year.
- Treat public API responses as untrusted and preserve timeouts, fallbacks, and null handling.
- Never add secrets or credentials to the browser bundle. Use an \`.env.example\` file if environment variables are introduced.
- Preserve the distinction between exploratory scores and qualified engineering, regulatory, environmental, or financial studies.
`;

write('src/data/scenarios.js', scenariosSource);
write('src/data/scenarios.test.js', scenariosTestSource);
write('AGENTS.md', agentsSource);

const packageJson = JSON.parse(read('package.json'));
packageJson.scripts = {
  ...packageJson.scripts,
  test: 'node --test',
};
write('package.json', JSON.stringify(packageJson, null, 2));

let main = read('src/main.jsx');
main = replaceOnce(
  main,
  "import { INDICE_PAGE_BY_ID, INDICE_PAGES } from './data/indices.js';\n",
  "import { INDICE_PAGE_BY_ID, INDICE_PAGES } from './data/indices.js';\nimport { buildEnergyEconomics, PROFILE_PRESETS, profileToPowerNeedMw } from './data/scenarios.js';\n",
  'scenario import',
);
main = replaceOnce(
  main,
  "const API_ADRESSE_LINK = 'https://adresse.data.gouv.fr/api-doc/adresse';\n",
  "const API_ADRESSE_LINK = 'https://adresse.data.gouv.fr/api-doc/adresse';\nconst HYPERSCALE_BENCHMARK_LINK = 'https://arxiv.org/abs/2504.16026';\n",
  'hyperscale benchmark link',
);
main = replaceRange(main, 'const PROFILE_PRESETS = [', 'const CRITERIA_LABELS = {', 'const CRITERIA_LABELS = {', 'inline profile presets');
main = replaceOnce(main, "  const [selectedProfileId, setSelectedProfileId] = useState('training');", "  const [selectedProfileId, setSelectedProfileId] = useState('colossus');", 'default scenario');
main = replaceOnce(
  main,
  `            {APP_NAME} croise la puissance électrique bas carbone, les contraintes naturelles
            et les signaux d’accès autour d’un point. Cliquez un département, puis un site
            potentiel pour obtenir un score d’aptitude.`,
  `            {APP_NAME} croise la puissance électrique bas carbone, les contraintes naturelles
            et les signaux d’accès pour des scénarios de 30 MW à 1 GW. Cliquez un département,
            puis un site potentiel pour obtenir un score d’aptitude et son ordre de grandeur énergétique.`,
  'landing scale copy',
);
main = replaceOnce(
  main,
  `      <GridConnectionPanel mode={mode} selectedMetric={selectedMetric} selectedProfile={selectedProfile} />

      <ProfileSelector`,
  `      <GridConnectionPanel mode={mode} selectedMetric={selectedMetric} selectedProfile={selectedProfile} />

      <ScaleEconomicsPanel mode={mode} selectedProfile={selectedProfile} />

      <ProfileSelector`,
  'economics panel placement',
);
const scaleEconomicsPanelSource = [
  'function ScaleEconomicsPanel({ mode, selectedProfile }) {',
  '  const economics = buildEnergyEconomics(selectedProfile);',
  '  const costLabel = `${formatDecimal(economics.electricityPriceEurPerKwh)} €/kWh`;',
  '',
  '  return (',
  "    <div className={cx('scale-economics grid gap-4 border p-4', mode === 'tension' ? 'border-black' : 'border-[#d8d0bd]')}>",
  '      <div className="flex items-start justify-between gap-4">',
  '        <div>',
  '          <p className="font-mono text-[0.62rem] uppercase tracking-[0.22em]">Échelle énergétique</p>',
  '          <p className="mt-2 font-display text-4xl leading-none text-ink">{formatMw(economics.powerMw)} MW</p>',
  '        </div>',
  '        <Zap aria-hidden="true" size={20} strokeWidth={1.25} />',
  '      </div>',
  '      <p className="text-sm leading-6 text-graphite">',
  '        {selectedProfile.reference ?? selectedProfile.label}. Charge totale site supposée constante, utilisée à la fois',
  '        pour le score de raccordement et les ordres de grandeur de consommation.',
  '      </p>',
  '      <div className="grid gap-2 text-sm leading-6">',
  '        <FactRow label="Énergie par jour" value={`${formatDecimal(economics.dailyEnergyGwh)} GWh`} />',
  '        <FactRow label="Énergie par mois" value={`${formatDecimal(economics.monthlyEnergyGwh)} GWh`} />',
  '        <FactRow label="Énergie par an" value={`${formatDecimal(economics.annualEnergyTwh)} TWh`} />',
  '        {economics.gpuCount > 0 && (',
  '          <FactRow',
  '            label="GPU modélisés"',
  '            value={`${formatNumber(economics.gpuCount)} · ${formatNumber(economics.gpuPowerAssumptionWatts)} W/GPU · ${formatMw(economics.gpuPowerMw)} MW GPU`}',
  '          />',
  '        )}',
  '        {economics.gpuSharePct != null && (',
  '          <FactRow label="Part puissance GPU" value={`${formatDecimal(economics.gpuSharePct)} %`} />',
  '        )}',
  '        <FactRow label={`${costLabel} · jour`} value={formatCompactEuro(economics.dailyCostEur)} />',
  '        <FactRow label={`${costLabel} · mois`} value={formatCompactEuro(economics.monthlyCostEur)} />',
  '        <FactRow label={`${costLabel} · an`} value={formatCompactEuro(economics.annualCostEur)} />',
  '      </div>',
  '      <p className="text-xs leading-5 text-graphite">',
  '        Hypothèses: 24 h/24, 30 jours par mois et 8 760 h par an. Hors achat des GPU, financement, maintenance,',
  '        renforcement réseau, combustible de secours et autres coûts d’exploitation.',
  '      </p>',
  '    </div>',
  '  );',
  '}',
  '',
  'function GridConnectionPanel({ mode, selectedMetric, selectedProfile }) {',
].join('\n');

main = replaceOnce(
  main,
  'function GridConnectionPanel({ mode, selectedMetric, selectedProfile }) {',
  scaleEconomicsPanelSource,
  'scale economics component',
);
main = replaceOnce(
  main,
  `  const confidence = buildConfidence(pointAnalysis, energy);
  const sortedCriteria`,
  `  const confidence = buildConfidence(pointAnalysis, energy);
  const economics = buildEnergyEconomics(selectedProfile);
  const sortedCriteria`,
  'memo economics calculation',
);
const memoScenarioSource = [
  '    `Scénario: ${selectedProfile.label} (${selectedProfile.footprint})`,',
  '    `Décision: ${verdict} · score ${Math.round(score)}/100`,',
].join('\n');
const memoScenarioWithScaleSource = [
  '    `Scénario: ${selectedProfile.label} (${selectedProfile.footprint})`,',
  '    `Échelle: ${formatMw(economics.powerMw)} MW continus, ${formatDecimal(economics.dailyEnergyGwh)} GWh/jour, ${formatDecimal(economics.annualEnergyTwh)} TWh/an, ${formatCompactEuro(economics.annualCostEur)}/an à ${formatDecimal(economics.electricityPriceEurPerKwh)} €/kWh`,',
  '    `Décision: ${verdict} · score ${Math.round(score)}/100`,',
].join('\n');
main = replaceOnce(main, memoScenarioSource, memoScenarioWithScaleSource, 'memo energy scale line');
main = replaceOnce(
  main,
  `  const profilePenalty =
    thresholdMw >= 160
      ? maxVoltageKv >= 400
        ? 0
        : maxVoltageKv >= 225
          ? 13
          : 30
      : thresholdMw >= 70
        ? maxVoltageKv >= 225
          ? 0
          : 14
        : maxVoltageKv >= 90
          ? 0
          : 10;`,
  `  const profilePenalty =
    thresholdMw >= 800
      ? maxVoltageKv >= 400
        ? 14
        : maxVoltageKv >= 225
          ? 42
          : 64
      : thresholdMw >= 250
        ? maxVoltageKv >= 400
          ? 0
          : maxVoltageKv >= 225
            ? 20
            : 46
        : thresholdMw >= 150
          ? maxVoltageKv >= 400
            ? 0
            : maxVoltageKv >= 225
              ? 10
              : 30
          : thresholdMw >= 70
            ? maxVoltageKv >= 225
              ? 0
              : maxVoltageKv >= 90
                ? 10
                : 20
            : maxVoltageKv >= 90
              ? 0
              : 10;`,
  'hyperscale voltage penalties',
);
main = replaceRange(main, 'function profileToPowerNeedMw(', 'function addRanks(', 'function addRanks(', 'inline power mapping');
main = replaceOnce(
  main,
  "    ['GeoJSON France', GEOJSON_LINK],\n",
  "    ['GeoJSON France', GEOJSON_LINK],\n    ['Benchmark hyperscale Epoch AI', HYPERSCALE_BENCHMARK_LINK],\n",
  'benchmark source link',
);
const compactEuroFormatterSource = [
  'function formatCompactEuro(value) {',
  '  const numericValue = Number(value ?? 0);',
  '  const safeValue = Number.isFinite(numericValue) ? numericValue : 0;',
  '  if (safeValue >= 1_000_000_000) return `${formatDecimal(safeValue / 1_000_000_000)} Md€`;',
  '  if (safeValue >= 1_000_000) return `${formatDecimal(safeValue / 1_000_000)} M€`;',
  '  if (safeValue >= 1_000) return `${formatNumber(safeValue / 1_000)} k€`;',
  '  return `${formatNumber(safeValue)} €`;',
  '}',
  '',
  'function formatMw(value) {',
].join('\n');
main = replaceOnce(main, 'function formatMw(value) {', compactEuroFormatterSource, 'compact euro formatter');
write('src/main.jsx', main);

let indices = read('src/data/indices.js');
indices = replaceOnce(
  indices,
  "  rteSubstations: 'https://odre.opendatasoft.com/explore/dataset/postes-electriques-rte/information/',\n",
  "  rteSubstations: 'https://odre.opendatasoft.com/explore/dataset/postes-electriques-rte/information/',\n  hyperscaleBenchmark: 'https://arxiv.org/abs/2504.16026',\n",
  'indices benchmark source',
);
indices = replaceOnce(
  indices,
  "      'Appliquer les pondérations du scénario choisi: cluster entraînement, campus souverain ou inférence régionale.',",
  "      'Appliquer les pondérations du scénario choisi: hyperscale 300 MW, stress test 1 GW, cluster entraînement, campus souverain ou inférence régionale.',",
  'indices scenario list',
);
indices = replaceOnce(
  indices,
  `      dataSource({
        name: 'ODRÉ, Caparéseau, postes électriques RTE, Eco2mix, Géorisques, Open-Meteo, Hub’Eau, VigiEau, DVF, API Adresse, OpenStreetMap',
        link: SOURCE_LINKS.odreEnergy,
        usage: 'Sources publiques utilisées par les indices sous-jacents.',
        freshness: 'Mélange de données live au clic et de jeux pré-agrégés quand les appels publics sont lourds ou instables.',
      }),`,
  `      dataSource({
        name: 'ODRÉ, Caparéseau, postes électriques RTE, Eco2mix, Géorisques, Open-Meteo, Hub’Eau, VigiEau, DVF, API Adresse, OpenStreetMap',
        link: SOURCE_LINKS.odreEnergy,
        usage: 'Sources publiques utilisées par les indices sous-jacents.',
        freshness: 'Mélange de données live au clic et de jeux pré-agrégés quand les appels publics sont lourds ou instables.',
      }),
      dataSource({
        name: 'Epoch AI — Trends in AI Supercomputers',
        link: SOURCE_LINKS.hyperscaleBenchmark,
        usage: 'Benchmark public pour l’ordre de grandeur 200 000 puces, 300 MW et plusieurs milliards de dollars de matériel.',
        freshness: 'Publication 2025; utilisée comme hypothèse de scénario, pas comme télémétrie du site.',
      }),`,
  'indices benchmark data source',
);
indices = replaceOnce(
  indices,
  "    question: 'Où l’accès réseau est-il crédible pour 30, 80 ou 200 MW ?',",
  "    question: 'Où l’accès réseau est-il crédible pour 30, 80, 200, 300 ou 1 000 MW ?',",
  'grid scale question',
);
indices = replaceOnce(
  indices,
  "      'Comparer la capacité disponible avec le besoin indicatif du scénario: 160 MW pour entraînement, 70 MW pour campus souverain, 25 MW pour inférence.',",
  "      'Comparer la capacité disponible avec le besoin explicite du scénario: 1 000 MW, 300 MW, 200 MW, 80 MW ou 30 MW.',",
  'explicit power needs',
);
indices = replaceOnce(
  indices,
  "      'Les capacités Caparéseau ne garantissent ni faisabilité, ni coût, ni délai, ni disponibilité contractuelle au moment du projet.',",
  "      'Les capacités Caparéseau ne garantissent ni faisabilité, ni coût, ni délai, ni disponibilité contractuelle au moment du projet.',\n      'À 300 MW et au-delà, l’agrégation départementale devient un préfiltre très grossier: plusieurs postes, renforcements et sources d’alimentation peuvent être nécessaires.',",
  'hyperscale grid limitation',
);
write('src/data/indices.js', indices);

let readme = read('README.md');
readme = replaceOnce(
  readme,
  '**PrismCenter est un prototype cartographique d\'aide à l\'identification de territoires propices à l\'implantation de datacenters IA en France, à partir de données publiques.**',
  '**PrismCenter est un prototype cartographique d\'aide à l\'identification de territoires propices à l\'implantation de datacenters IA en France, avec des scénarios explicites de 30 MW à 1 GW.**',
  'README introduction',
);
readme = replaceOnce(
  readme,
  '2. mesurer si le raccordement électrique paraît crédible pour 30, 80 ou 200 MW;',
  '2. mesurer si le raccordement électrique paraît crédible pour 30, 80, 200, 300 ou 1 000 MW;',
  'README power list',
);
readme = replaceOnce(
  readme,
  '- Profils de pondération selon le type de datacenter: cluster d’entraînement, campus souverain, inférence régionale.',
  '- Profils de pondération selon le type de datacenter: hyperscale 300 MW, stress test 1 GW, cluster d’entraînement, campus souverain et inférence régionale.',
  'README profiles',
);
readme = replaceOnce(
  readme,
  '| [ODRÉ - Eco2mix national temps réel](https://odre.opendatasoft.com/explore/dataset/eco2mix-national-tr/information/) | Consommation, solaire et intensité CO2 nationale | National | Chargement au démarrage avec fallback |',
  '| [ODRÉ - Eco2mix national temps réel](https://odre.opendatasoft.com/explore/dataset/eco2mix-national-tr/information/) | Consommation, solaire et intensité CO2 nationale | National | Chargement au démarrage avec fallback |\n| [Epoch AI - Trends in AI Supercomputers](https://arxiv.org/abs/2504.16026) | Benchmark hyperscale: 200 000 puces, 300 MW et coût matériel estimé | International | Hypothèse de scénario, non télémétrie live |',
  'README benchmark source',
);
readme = replaceOnce(
  readme,
  '- **Raccordement électrique**: capacité réservée disponible Caparéseau, tension RTE, densité de postes et cohérence avec le besoin MW du scénario.',
  '- **Raccordement électrique**: capacité réservée disponible Caparéseau, tension RTE, densité de postes et cohérence avec un besoin explicite de 30 MW à 1 GW.',
  'README grid model',
);
readme = replaceOnce(
  readme,
  '## Architecture',
  `## Scénarios De Puissance

Les scénarios portent désormais un besoin électrique explicite. Le profil par défaut représente un ordre de grandeur proche de Colossus 1, sans prétendre reproduire sa télémétrie réelle.

| Scénario | Besoin site | Hypothèse GPU | Énergie continue | Coût à 0,08 €/kWh |
| --- | ---: | ---: | ---: | ---: |
| Hyperscale IA | 300 MW | 200 000 GPU, 140 MW GPU | 7,2 GWh/jour; 2,628 TWh/an | 576 k€/jour; 210,24 M€/an |
| Campus gigawatt | 1 000 MW | 1 million de GPU équivalents, 700 MW GPU | 24 GWh/jour; 8,76 TWh/an | 1,92 M€/jour; 700,8 M€/an |
| Cluster entraînement | 200 MW | Non imposée | 4,8 GWh/jour; 1,752 TWh/an | 384 k€/jour; 140,16 M€/an |
| Campus souverain | 80 MW | Non imposée | 1,92 GWh/jour; 0,701 TWh/an | 153,6 k€/jour; 56,06 M€/an |
| Inférence régionale | 30 MW | Non imposée | 0,72 GWh/jour; 0,263 TWh/an | 57,6 k€/jour; 21,02 M€/an |

Les coûts supposent une charge constante 24 h/24, 30 jours par mois et 8 760 heures par an. Ils excluent le matériel, le financement, la maintenance, les renforcements réseau, les combustibles de secours et les autres coûts d’exploitation.

## Architecture`,
  'README scenarios section',
);
readme = replaceOnce(
  readme,
  '| Livré | Raccordement électrique | Où approcher 30, 80 ou 200 MW de manière crédible ? | Caparéseau, capacités d’accueil réseau, postes RTE | Très fort |',
  '| Livré | Raccordement électrique | Où approcher 30 MW à 1 GW de manière crédible ? | Caparéseau, capacités d’accueil réseau, postes RTE | Très fort |',
  'README roadmap',
);
readme = replaceOnce(
  readme,
  '- Les capacités Caparéseau sont rapprochées au département: elles ne valent pas promesse de raccordement, coût, délai ou disponibilité contractuelle.',
  '- Les capacités Caparéseau sont rapprochées au département: elles ne valent pas promesse de raccordement, coût, délai ou disponibilité contractuelle.\n- À 300 MW et surtout à 1 GW, le résultat est un stress test territorial; il ne modélise pas un schéma électrique multi-postes, une centrale dédiée, des turbines, des batteries ou un phasage de construction.',
  'README hyperscale limitation',
);
write('README.md', readme);

